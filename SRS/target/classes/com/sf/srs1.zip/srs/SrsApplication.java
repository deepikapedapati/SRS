package com.sf.srs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrsApplication.class, args);
		System.out.println("Ready");
	}

}
