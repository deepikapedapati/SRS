package com.sf.srs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sf.srs.bean.Route;
import com.sf.srs.bean.Schedule;
import com.sf.srs.bean.Ship;
import com.sf.srs.service.Administratorservice;



@RestController
@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/admin")
public class Administratorcontroller {
	@Autowired
	private Administratorservice adserv;
@PostMapping("/addShip")
public String add(@RequestBody Ship eb)
{
	adserv.addShip(eb);
	return "<h1>Ship Added Successfully</h1>";
}
@GetMapping("/selectAll")
public List<Ship> viewall()
{
	
	return adserv.viewShip();
}
@PutMapping("/updateShip")
public String update(@RequestBody Ship eb)
{
	adserv.updateShip(eb);
	return "<h1>Ship Updated successfully</h1>";
}
@GetMapping("/ship/{id}")
public Ship viewid(@PathVariable(value = "id") int Shipid)
{
	return adserv.viewShipById(Shipid);
	
}
@DeleteMapping("/deleteShip/{id}")
public String delete(@PathVariable(value="id") int Shipid)
{
	return "<h1>"+adserv.deleteShip(Shipid)+" record deleted successfully</h1>";
}






@PostMapping("/addSchedule")
public String add(@RequestBody Schedule eb)
{
	adserv.addSchedule(eb);
	return "<h1>Schedule Added Successfully</h1>";
}
@GetMapping("/AllSchedule")
public List<Schedule> viewallschedule()
{
	
	return adserv.viewSchedule();
}
@PutMapping("/updateSchedule")
public String update(@RequestBody Schedule eb)
{
	adserv.updateSchedule(eb);
	return "<h1>Schedule Updated successfully</h1>";
}
@GetMapping("/Schedule/{id}")
public Schedule viewScheduleid(@PathVariable(value = "id") int Scheduleid)
{
	return adserv.viewScheduleById(Scheduleid);
	
}
@DeleteMapping("/deleteSchedule/{id}")
public String deleteSchedule(@PathVariable(value="id") int Scheduleid)
{
	return "<h1>"+adserv.deleteSchedule(Scheduleid)+" record deleted successfully</h1>";
}




@PostMapping("/addRoute")
public String add(@RequestBody Route eb)
{
	adserv.addRoute(eb);
	return "<h1>Route Added Successfully</h1>";
}
@GetMapping("/AllRoute")
public List<Route> viewallRoutes()
{
	
	return adserv.viewRoute();
}
@PutMapping("/updateRoute")
public String update(@RequestBody Route eb)
{
	adserv.updateRoute(eb);
	return "<h1>Route Updated successfully</h1>";
}
@GetMapping("/Route/{id}")
public Route viewRouteid(@PathVariable(value = "id") int Routeid)
{
	return adserv.viewRouteById(Routeid);
	
}
@DeleteMapping("/deleteRoute/{id}")
public String deleteRoute(@PathVariable(value="id") int Routeid)
{
	return "<h1>"+adserv.deleteRoute(Routeid)+" record deleted successfully</h1>";
}
}