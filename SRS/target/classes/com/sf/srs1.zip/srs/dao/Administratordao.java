package com.sf.srs.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sf.srs.bean.Route;
import com.sf.srs.bean.Schedule;
import com.sf.srs.bean.Ship;




@Repository
public class Administratordao {
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	private Query<Ship>q;
	private Query<Schedule>q1;
	private Query<Route>q2;
	
	public String addShip(Ship ship) 
	{
		if(ship!=null)
		{
			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.save(ship);
			transaction.commit();
			session.close();
			return "SUCCESS";
		}
		else if(ship==null)
		{
			return "ERROR";
		}
		else
		{
			return "FAIL";
		}
	}
	
	public String updateShip(Ship ship)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(ship!=null)
		{
		session.update(ship);

		transaction.commit();

		session.close();
		return "SUCCESS";
		}
		else if(ship==null)
		{
			return "FAIL";
		}
		else
		{
			return "ERROR";
		}
	}
	public String deleteShip(int shipId)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(shipId>=0)
		{
		Query q=session.createQuery("delete from Ship where shipID=:sid");
		q.setParameter("sid", shipId);
		q.executeUpdate();
transaction.commit();
session.close();
		return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
	}
	public ArrayList<Ship> viewShips()
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		q=session.createQuery("from Ship");
		return (ArrayList<Ship>) q.list();
	}
	public Ship viewShipByid(int shipid)
	{
		Ship elBean=new Ship();
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
	Query<Ship> q=session.createQuery("from Ship where shipid=:sid");
	q.setParameter("sid", shipid);
	ArrayList<Ship> all=(ArrayList<Ship>) q.getResultList();
	for(Ship e1:all)
	{
		elBean=e1;
	}
	return elBean;
	}
	
	
	
	
	public String addSchedule(Schedule schedule) 
	{
		if(schedule!=null)
		{
			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.save(schedule);
			transaction.commit();
			session.close();
			return "SUCCESS";
		}
		else if(schedule==null)
		{
			return "ERROR";
		}
		else
		{
			return "FAIL";
		}
	}
	
	public String updateSchedule(Schedule schedule)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(schedule!=null)
		{
		session.update(schedule);

		transaction.commit();

		session.close();
		return "SUCCESS";
		}
		else if(schedule==null)
		{
			return "FAIL";
		}
		else
		{
			return "ERROR";
		}
	}
	public String deleteSchedule(int ScheduleId)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(ScheduleId>=0)
		{
		Query q1=session.createQuery("delete from Schedule where scheduleID=:scid");
		q1.setParameter("scid", ScheduleId);
		q1.executeUpdate();
transaction.commit();
session.close();
		return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
	}
	public ArrayList<Schedule> viewSchedules()
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		q=session.createQuery("from Schedule");
		return (ArrayList<Schedule>) q1.list();
	}
	public Schedule viewScheduleByid(int Scheduleid)
	{
		Schedule s1Bean=new Schedule();
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
	Query<Schedule> q1=session.createQuery("from Ship where shipid=:scid");
	q1.setParameter("scid", Scheduleid);
	ArrayList<Schedule> all=(ArrayList<Schedule>) q1.getResultList();
	for(Schedule e2:all)
	{
		s1Bean=e2;
	}
	return s1Bean;
	}
	
	
	
	
	public String addRoute(Route route) 
	{
		if(route!=null)
		{
			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.save(route);
			transaction.commit();
			session.close();
			return "SUCCESS";
		}
		else if(route==null)
		{
			return "ERROR";
		}
		else
		{
			return "FAIL";
		}
	}
	
	public String updateRoute(Route route)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(route!=null)
		{
		session.update(route);

		transaction.commit();

		session.close();
		return "SUCCESS";
		}
		else if(route==null)
		{
			return "FAIL";
		}
		else
		{
			return "ERROR";
		}
	}
	public String deleteRoute(int RouteId)
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(RouteId>=0)
		{
		Query q2=session.createQuery("delete from Route where RouteID=:rid");
		q2.setParameter("rid", RouteId);
		q2.executeUpdate();
transaction.commit();
session.close();
		return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
	}
	public ArrayList<Route> viewRoutes()
	{
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		q2=session.createQuery("from Route");
		return (ArrayList<Route>) q2.list();
	}
	public Route viewRouteByid(int routeid)
	{
		Route rBean=new Route();
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
	Query<Route> q2=session.createQuery("from Route where Routeid=:rid");
	q2.setParameter("rid", routeid);
	ArrayList<Route> all=(ArrayList<Route>) q2.getResultList();
	for(Route e3:all)
	{
		rBean=e3;
	}
	return rBean;
	}
}
	


