package com.sf.srs.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL_Ship")

public class Ship {
	@Id
	@Column
	private int Shipid;
	@Column
	private String ShipName;
	@Column
	private String SeatingCapacity;
	@Column
	private String ReservationCapacity;
	public int getShipid() {
		return Shipid;
	}
	public void setShipid(int shipid) {
		Shipid = shipid;
	}
	public String getShipName() {
		return ShipName;
	}
	public void setShipName(String shipName) {
		ShipName = shipName;
	}
	public String getSeatingCapacity() {
		return SeatingCapacity;
	}
	public void setSeatingCapacity(String seatingCapacity) {
		SeatingCapacity = seatingCapacity;
	}
	public String getReservationCapacity() {
		return ReservationCapacity;
	}
	public void setReservationCapacity(String reservationCapacity) {
		ReservationCapacity = reservationCapacity;
	}
	
	

}
