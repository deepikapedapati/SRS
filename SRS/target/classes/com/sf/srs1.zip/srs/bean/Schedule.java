package com.sf.srs.bean;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL_Schedule")
public class Schedule {
	@Id
	@Column
	private int ScheduleId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="RouteId",referencedColumnName="RouteId")
	private Route route;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ShipId",referencedColumnName="ShipId")
	private Ship ship;
	@Column
	private String startDate;
	public int getScheduleId() {
		return ScheduleId;
	}
	public void setScheduleId(int scheduleId) {
		ScheduleId = scheduleId;
	}
	
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	public Ship getShip() {
		return ship;
	}
	public void setShip(Ship ship) {
		this.ship = ship;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	

}
