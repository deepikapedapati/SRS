package com.sf.srs.bean;

import jakarta.persistence.CascadeType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL-Passenger")

public class Passenger {
	@Id
	private int pvid;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ReservationId",referencedColumnName="ReservationId")
	private Reservation reservation;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name= "ScheduleId",referencedColumnName="ScheduleId")
	private Schedule schedule;
	
	@Column
	private String Name;
	@Column
	private String Age;
	@Column
	private String Gender;
	
	public int getPvid() {
		return pvid;
	}
	public void setPvid(int pvid) {
		this.pvid = pvid;
	}
	public Reservation getReservation() {
		return reservation;
	}
	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	

}
