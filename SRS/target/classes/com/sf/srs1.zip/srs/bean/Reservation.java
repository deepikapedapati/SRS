package com.sf.srs.bean;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL_Reservation")
public class Reservation {
	@Id
	@Column
	private int ReservationId;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ScheduleId",referencedColumnName="ScheduleId")
	private Schedule schedule;

	@ManyToOne (cascade = CascadeType.ALL)
	@JoinColumn(name="UserId",referencedColumnName="UserId")
	private Credentials credentials;
	@Column
	private String BookingDate;
	@Column
	private String JourneyDate;
	@Column
	private String NoOfSeats;
	@Column
	private String Totalefare;
	@Column
	private String BookingStatus;
	public int getReservationId() {
		return ReservationId;
	}
	public void setReservationId(int reservationId) {
		ReservationId = reservationId;
	}
		
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}
	public Credentials getCredentials() {
		return credentials;
	}
	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}
	public String getBookingDate() {
		return BookingDate;
	}
	public void setBookingDate(String bookingDate) {
		BookingDate = bookingDate;
	}
	public String getJourneyDate() {
		return JourneyDate;
	}
	public void setJourneyDate(String journeyDate) {
		JourneyDate = journeyDate;
	}
	public String getNoOfSeats() {
		return NoOfSeats;
	}
	public void setNoOfSeats(String noOfSeats) {
		NoOfSeats = noOfSeats;
	}
	public String getTotalefare() {
		return Totalefare;
	}
	public void setTotalefare(String totalefare) {
		Totalefare = totalefare;
	}
	public String getBookingStatus() {
		return BookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		BookingStatus = bookingStatus;
	}
	
	

}
