package com.sf.srs.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL_Route")
public class Route {
	@Id
	@Column
	private int RouteId;
	@Column
	private String Source;
	@Column
	private String Destination;
	@Column
	private String TravelDuration;
	@Column
	private String Fare;
	public int getRouteId() {
		return RouteId;
	}
	public void setRouteId(int routeId) {
		RouteId = routeId;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getTravelDuration() {
		return TravelDuration;
	}
	public void setTravelDuration(String travelDuration) {
		TravelDuration = travelDuration;
	}
	public String getFare() {
		return Fare;
	}
	public void setFare(String fare) {
		Fare = fare;
	}
	

}
