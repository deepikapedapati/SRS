package com.sf.srs.bean;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="SRS_TBL_User_Profile")

public class Profile {
	@Id
	private String pid;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="UserId",referencedColumnName="UserId")
	private Credentials credentials;
	@Column
	private String Firstname;
	@Column
	private String Lasrtname;
	@Column
	private String DateOfBirth;
	@Column
	private String Gnder;
	@Column
	private String Street;
	@Column
	private String Location;
	@Column
	private String City;
	@Column
	private String  State;
	@Column
	private String Pincode;
	@Column
	private String MobileNo;
	@Column
	private String EmailId;
	
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Credentials getCredentials() {
		return credentials;
	}
	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLasrtname() {
		return Lasrtname;
	}
	public void setLasrtname(String lasrtname) {
		Lasrtname = lasrtname;
	}
	public String getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public String getGnder() {
		return Gnder;
	}
	public void setGnder(String gnder) {
		Gnder = gnder;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPincode() {
		return Pincode;
	}
	public void setPincode(String pincode) {
		Pincode = pincode;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	

}
