package com.sf.srs.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sf.srs.bean.Route;
import com.sf.srs.bean.Schedule;
import com.sf.srs.bean.Ship;
import com.sf.srs.dao.Administratordao;

@Service
public   class Administratorservice  {
	@Autowired
	private Administratordao adao;
	public String addShip(Ship ship)
	{
		return
	adao.addShip(ship);
	}
	public ArrayList<Ship>
	viewShip()
	{
		return adao.viewShips();
	}
	public String
	updateShip(Ship ship)
	{
		return
				adao.updateShip(ship);
	}
	public String deleteShip( int shipid)
	{
		return
				adao.deleteShip(shipid);
	}
	public Ship
	viewShipById(int shipid)
	{
		return
				adao.viewShipByid(shipid);
}
	
	
	
	public String addSchedule(Schedule schedule)
	{
		return
	adao.addSchedule(schedule);
	}
	public ArrayList<Schedule>
	viewSchedule()
	{
		return adao.viewSchedules();
	}
	public String
	updateSchedule(Schedule schedule)
	{
		return
				adao.updateSchedule(schedule);
	}
	public String deleteSchedule( int scheduleid)
	{
		return
				adao.deleteSchedule(scheduleid);
	}
	public Schedule
	viewScheduleById(int Scheduleid)
	{
		return
				adao.viewScheduleByid(Scheduleid);
}
	
	
	
	
	public String addRoute(Route route)
	{
		return
	adao.addRoute(route);
	}
	public ArrayList<Route>
	viewRoute()
	{
		return adao.viewRoutes();
	}
	public String
	updateRoute(Route route)
	{
		return
				adao.updateRoute(route);
	}
	public String deleteRoute( int routeid)
	{
		return
				adao.deleteRoute(routeid);
	}
	public Route
	viewRouteById(int routeid)
	{
		return
				adao.viewRouteByid(routeid);
}


}